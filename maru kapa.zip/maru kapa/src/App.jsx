import React from "react"
import Etiqueta from "./components/Card";
import "./components/Card/index.module.css"

function App() {
    return (
        <div className="app-container">
            <Etiqueta
                title="Tarea 1"
                description="Esta es la descripción de la tarea 1."
                assignedTo="Luana"
                startDate="2024-09-15"
                endDate="2024-09-20"
            />
            <Etiqueta
                title="Tarea 2"
                description="Descripción de la tarea 2."
                assignedTo="Carlos"
                startDate="2024-09-16"
                endDate="2024-09-21"
            />
            <Etiqueta
                title="Tarea 3"
                description="Tercera tarea a completar."
                assignedTo="Ana"
                startDate="2024-09-17"
                endDate="2024-09-22"
            />
        </div>
    );
}

export default App;

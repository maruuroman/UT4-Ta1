import React from "react";
import classes from "./index.module.css"; 

const Etiqueta = ({ title, description, assignedTo, startDate, endDate }) => {
    return (
        <div className={classes.container}>
            <h2>{title}</h2>
            <p>{description}</p>
            <p><strong>Asignado a:</strong> {assignedTo}</p>
            <p><strong>Fecha de inicio:</strong> {startDate}</p>
            <p><strong>Fecha de cierre:</strong> {endDate}</p>
        </div>
    );
};

export default Etiqueta